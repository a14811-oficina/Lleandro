#Ciclos: while e for

'''
#Exercício B1 - Contagem Simples (while) 
i = 1 
while i < 11:
    print("i")
    i+=1

#Exercício B2 - Contagem Decrescente (while)
i = 10
while i > 1:
    print(i)
    i -= 1

#Exercício B3 - Contagem com for

for i in range (0,21):
    print(i)
    i =+ 1

#Exercício B4 - Números Pares
for i in range (0,21,2):
    print(i)
    i =+ 1

#Exercício I1 - Soma de 1 a 100
soma = 0
for i in range (1,101):
    soma  += 1
    print(f"a somar {i} soma atual {soma}")
    print(F"o resultado final: {soma}")

#Exercício I2 - Tabuada
num = int(input("insere um numero: "))
while num > 0:
    print(num)
    num = int(input("insere o numero: "))
else:
    print("o programa foi interrompido")

#Exercício I3 - Contador de Pares
pares = i
for i in range (0,51,2):
    print(pares)

print(f'tem {pares} numeros pares')
    
#if i % 2 == 0:

#exercio A1-soma personalizada

quantidade = int(input("Quantos números quer inserir? "))

soma = 0

for i in range(quantidade):
    numero = float(input("Digite um número: "))
    soma = soma + numero

print("A soma total é:", soma)

#Exercício A2 – Menu Repetitivo

opcao = -1

while opcao != 0:
    print("\nMenu")
    print("1 - Mostrar números de 1 a 10")
    print("2 - Mostrar números pares até 20")
    print("0 - Sair")

    opcao = int(input("Escolha uma opção: "))

    if opcao == 1:
        for i in range(1, 11):
            print(i)

    elif opcao == 2:
        for i in range(2, 21, 2):
            print(i)

    elif opcao == 0:
        print("Programa terminado.")

    else:
        print("Opção inválida.")

#Exercício A3 – Fatorial

numero = int(input("Digite um número: "))

fatorial = 1

for i in range(1, numero + 1):
    fatorial = fatorial * i

print(numero, "! =", fatorial)
'''
    
