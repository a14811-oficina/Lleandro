 #Exercício B1 - Número Positivo ou Negativo
num = int(input("digite o numero"))
if num >= 0:
     print(f'o numero{num} e positivo')
else: 
     print(f'o numero{num} e negativo')

 #Exercício B2 - Maior de Idade

idade = int(input("insere a tua idade"))
if idade < 13:
     print("es uma criança!")
elif idade <= 17:
    print("es jovem!")
elif idade <= 64:
     print("es adulto")
else:
    print("es senior")

   #Exercício B3 - Número Par ou Ímpar

num_2 = int(input("insere o numero"))
if num_2 % 2:
    print('f o numero {num_2} e par')
else:
    print('f o numero{num_2} e impar')

 #Exercício B4 - Comparação de Dois Números
 
opA = int(input(" insere o primeiro numero"))
opB = int(input("insere o segundo numero"))
if opA > opB:
    print(f'o numero {opA} e o maior numero')
else:
    print(f'o numero {opB} e o maior numero')

#Exercício B5 - Password Simples

password = input("digite a sua palavra-passe: ")

print( password == "python")

#Exercício I1 - Classificação de Nota
nota = float(input("insira a nota: "))

print(nota >= 10)


opA = int(input("insere o maior"))
print("valor % 2")
'''
#Exercício I2 - Classificação de Idade

idade = int(input("insere a tua idade"))
if idade < 13:
   print("es uma criança!")
elif idade <= 17:
    print("es jovem!")
elif idade <= 64:
    print("es adulto")
else:
    print("es senior")

#Exercício I3 - Múltiplo de 3 e 5







#Exercício I4 - Login com Utilizador e Password
user = input("digite o seu utilizador: ")
password = input("digite a sua palavra-passe: ")

print(user =="admin"  and password == "1234")

'''
# Exercício I5 - Número dentro de intervalo

numero = float(input("Digite um número: "))

if 10 <= numero <= 20:
    print("O número está entre 10 e 20.")
else:
    print("O número NÃO está entre 10 e 20.")

#Exercício A1 - Sistema Multibanco Simples
saldo = 100
valor_a_levantar = int(input("insere o valor a levantar: "))
saldo_restante = saldo - valor_a_levantar
if valor_a_levantar >= saldo:
    print(f"levantou {valor_a_levantar}.")
else:
    print("Nao consegues levantar esse valor. ")
print(f"ficarias com {saldo_restante} euros.")


#Exercício A2 - Maior de Quatro Números


n1 = float(input("Digite o primeiro número: "))
n2 = float(input("Digite o segundo número: "))
n3 = float(input("Digite o terceiro número: "))
n4 = float(input("Digite o quarto número: "))

maior = n1

if n2 > maior:
    maior = n2
if n3 > maior:
    maior = n3
if n4 > maior:
    maior = n4

print("O maior número é:", maior)



#Exercício A3 - Classificação de IMC (Simplificado)

peso = float(input("digite o peso: "))
altura = float(input("digite a altura: "))

imc = peso / (altura * peso)

if imc < 18.5:
    print("baixo peso")
elif imc <= 24.9:
    print("normal")
elif imc  <= 29.9: 
    print("Excesso de peso")
else:
    print("obesidade")

print(imc)


#Exercício A4 - Sistema de Desconto
valor_da_compra = int(input("insere o valor da compra"))

if valor_da_compra >= 100:
   desconto = valor_da_compra * 0.1
   valor_final = valor_da_compra - desconto
   print(f'O desconto é de (desconto)')
elif valor_da_compra >=50
    desconto = valor_da_compra *0.05


#Exercício A5 - Verificação de Ano Bissexto (Simplificado)

ano = int(input("Digite um ano: "))

if ano % 4 == 0:
    print("Ano bissexto")
else:
    print("Ano normal")















 
